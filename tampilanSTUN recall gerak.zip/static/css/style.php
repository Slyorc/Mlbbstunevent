<?php
$emailku = 'ryuc0d3x@gmail.com';
